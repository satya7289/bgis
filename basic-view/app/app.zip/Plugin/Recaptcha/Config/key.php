<?php

$config = array(
	'Recaptcha' => array(
		'Public'  => '6LeZj_kSAAAAAJwbGHR_x0P3rmfR2Kg5xMh6YTof',
		'Private' => '6LeZj_kSAAAAAAVbctJtgE8OkzkRDRqmauPvys8N',
	),
);

?>