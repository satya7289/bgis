<?php
Configure::load('Recaptcha.key', 'default');