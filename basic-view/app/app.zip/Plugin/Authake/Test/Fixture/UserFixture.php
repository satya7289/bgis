<?php
class UserFixture extends CakeTestFixture {
    public $import = array('model' => 'User', 'records' => true);
}
?>