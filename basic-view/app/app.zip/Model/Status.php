<?php
class Status extends AppModel {
	var $name = 'Status';
	var $displayField = 'status_title';
	
	//The Associations below have been created with all possible keys, those that are not needed can be removed
}
?>