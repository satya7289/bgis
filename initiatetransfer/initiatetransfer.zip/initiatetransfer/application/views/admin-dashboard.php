				<div class="grid-ibx grid-ibx--cols-3 grid-ibx--style-lined-center grid-ibx--hover-shadow">
							<div class="grid-ibx__inner">
								<div class="grid-ibx__row clearfix">
									<div class="grid-ibx__item h-300">
										<div class="grid-ibx__item-inner">
											<div class="grid-ibx__title-wrp">
												<h4 class="grid-ibx__title kl-font-alt fs-m">
													ADMINSSIONS
												</h4>
											</div>
											<div class="grid-ibx__icon-wrp">
												<span class="grid-ibx__icon icon-gi-ico-4 fs-xxxl"></span>
											</div>
											<div class="grid-ibx__desc-wrp">
												<p class="grid-ibx__desc">
													Documentation include with explanations for most of the options.
												</p>
											</div>
										</div>
									</div>
									<!--/ Item - height 300px - .grid-ibx__item -->

										<div class="grid-ibx__item h-300">
										<div class="grid-ibx__item-inner">
											<div class="grid-ibx__title-wrp">
												<h4 class="grid-ibx__title kl-font-alt fs-m">
													DONATIONS
												</h4>
											</div>
											<div class="grid-ibx__icon-wrp">
												<span class="grid-ibx__icon icon-gi-ico-4 fs-xxxl"></span>
											</div>
											<div class="grid-ibx__desc-wrp">
												<p class="grid-ibx__desc">
													Documentation include with explanations for most of the options.
												</p>
											</div>
										</div>
									</div>
									<!--/ Item - height 300px - .grid-ibx__item -->

								 <!--/ Item - height 300px - .grid-ibx__item -->

										<div class="grid-ibx__item h-300">
										<div class="grid-ibx__item-inner">
											<div class="grid-ibx__title-wrp">
												<h4 class="grid-ibx__title kl-font-alt fs-m">
													OTHERS
												</h4>
											</div>
											<div class="grid-ibx__icon-wrp">
												<span class="grid-ibx__icon icon-gi-ico-4 fs-xxxl"></span>
											</div>
											<div class="grid-ibx__desc-wrp">
												<p class="grid-ibx__desc">
													Documentation include with explanations for most of the options.
												</p>
											</div>
										</div>
									</div>
									<!--/ Item - height 300px - .grid-ibx__item -->
 

							 
								
							</div>
							<!--/ .grid-ibx__inner -->
						</div>
						<!--/ Grid icon box element 3 cols lined style - .grid-ibx-->














							
					</div> 
				</div> 
			</div> 
		</div>
</div>



















