 <div class="grid-ibx grid-ibx--cols-3 grid-ibx--style-lined-center grid-ibx--hover-shadow">
		<div class="grid-ibx__inner">
			<div class="grid-ibx__row clearfix">
				<table width='750' border='0' align='center' cellpadding='0' cellspacing='0' style='border:solid 1px #bcc2cf'> 
				 <tbody> 
				 	<tr style="background-color: #fff">
				 		<td align='left' valign='middle' style='padding:15px 0px'> 
				 			<a href='https://newbgis.org' target='_blank' data-saferedirecturl='https://www.google.com/url?hl=en&amp;q=https://newbgis.org&amp;source=gmail&amp;ust=1520745983793000&amp;usg=AFQjCNEjZrlcAirJOrAe_LDyITQR0zZ_xA'>
				 				<img alt='LOGO' src='https://ci6.googleusercontent.com/proxy/yYoAcFnxccSJ2jUQrxQTZwRafKwXd3px5H32BjN_esypKR53uAl8ve3mGF8QcM0D0ZHtmryxX_Th8vhrAXoUSCD63Wk4ArYhdNslIaQ_8Cd6huem3Ip3YRDQwDT6h8j2rwIjwQFtmQ=s0-d-e1-ft#https://dashboard.ccavenue.com/ImgStore/Images/50225_GtwSetlogo_1516705188477.png' border='0' class='CToWUd'></a> 
				 		</td>
				 	<td>
				 		<h1 style='color: #b31111'>Bhaktivedanta Gurukula & International School</h1> 
				 	</td>
				</tr>
				 	<tr>
				 	 <td colspan='2' align='left' valign='top' class='m_2109585722555529806maincontainer' style='font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#373737;background-color:#fff;padding:20px'>Dear <strong><?php echo $invoiceDetails[0]->billing_name ?></strong>,<br><br>Thank you for the kind Contribution towords Bhaktivedanta Gurukula and International School <br><br>Attached below is the receipt of your transaction :<br><br><table width='100%' border='0' cellspacing='0' cellpadding='0'> 
				 <tbody> 
				 	<tr>
				 	 <td align='left' valign='top' class='m_2109585722555529806innercontainer' style='background-color:#fff;padding:15px 20px;border:solid 1px #dbdfe6'> 
				 	 	<table width='100%' border='0' cellspacing='0' cellpadding='6' class='m_2109585722555529806innerborder'> 
				 	 		<tbody> <tr class='m_2109585722555529806tableinner'> 
				 	 			<td width='47%' height='18' align='left' valign='middle' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737;background-color:#f7f7f7'><strong>Receipt #</strong> 
				 	 			</td>
				 		<td width='35%' height='18' align='left' valign='middle' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737;background-color:#f7f7f7;border-left:solid 1px #e4e6eb'><strong>Tracking #</strong> 
				 		</td>
				 	<td width='18%' height='18' align='left' valign='middle' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737;background-color:#f7f7f7;border-left:solid 1px #e4e6eb'><strong>Payment Date</strong> 
				 	</td>
				 </tr>
				 	<tr>
				 	 <td colspan='3' align='left' valign='middle' class='m_2109585722555529806divider' height='1'> <img src='https://ci6.googleusercontent.com/proxy/Kqk_m_z9N-awTI-YYNBkynZxsDUaLUm7fDOTl1tIrXUTL26CWioJ3zIOrDM2UcQ8Oytloc6VuyvxhSLoc-QMZAg8mRPSk35YBQ=s0-d-e1-ft#https://secure.ccavenue.com/images/blank_spacer.gif' width='1' height='1' class='CToWUd'> 
				 	 </td>
				 	</tr>
				 <tr>
				  <td width='47%' height='18' align='left' valign='middle' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737;background-color:#f7f7f7'><?php echo $invoiceDetails[0]->order_id ?>
				  </td>
				 <td width='35%' height='18' align='left' valign='middle' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737;background-color:#f7f7f7;border-left:solid 1px #e4e6eb'><?php echo $invoiceDetails[0]->tracking_id ?>				 	
				 </td>
				 <td width='18%' height='18' align='left' valign='middle' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737;background-color:#f7f7f7;border-left:solid 1px #e4e6eb'> <span class='aBn' data-term='goog_1965848113' tabindex='0'> <span class='aQJ'><?php echo $invoiceDetails[0]->trans_date ?></span> </span>
				</td>
				</tr>
				</tbody> 
			</table> <br><br>
				<table width='100%' border='0' cellspacing='0' cellpadding='0'> 
					<tbody> 
						<tr>
				 		 <td height='25' colspan='3' align='left' valign='top' class='m_2109585722555529806title' style='font-family:Arial,Helvetica,sans-serif;font-size:15px;color:#0072c6;border-bottom:solid 1px #dbdfe6'>Payment Details
				 		 </td>
				 </tr>
				 	<tr>
				 	 <td colspan='3' align='left' valign='top'>&nbsp;</td>
				 	</tr>
				 <tr>
				  <td width='412' align='left' valign='top'> <table width='100%' border='0' cellspacing='0' cellpadding='4'> <tbody> <tr>
				  <td width='23%' align='right' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'><strong>Name: </strong> </td>
				 	<td width='77%' align='left' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'> &nbsp;<?php echo $invoiceDetails[0]->billing_name ?></td>
				</tr>
				 	<tr>
				 	 <td align='right' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'><strong>Address : </strong></td>
				 		<td align='left' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'> &nbsp; <?php echo $invoiceDetails[0]->billing_address ?></td>
				 </tr>
				 <tr>
				  <td align='right' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'><strong>Mobile Number : </strong></td>
				 	<td align='left' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'> &nbsp;<?php echo $invoiceDetails[0]->billing_tel ?></td>
				</tr>
				 <tr>
				  <td align='right' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'><strong>Email Address : </strong></td>
				 	<td align='left' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'> &nbsp; <?php echo $invoiceDetails[0]->billing_email ?></td>
				</tr>
				 <tr>
				  <td align='right' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'><strong>Payment Method: </strong></td>
				 	<td align='left' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'> &nbsp;<?php echo $invoiceDetails[0]->payment_mode ?></td>
				</tr>
				 <tr>
				  <td align='right' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'><strong>Status : </strong></td>
				 	<td align='left' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'> &nbsp; <?php echo $invoiceDetails[0]->order_status ?></td>
				</tr>
				 <tr>
				  </tbody> 
				</table> 
			</td>
				 <td width='20' align='left' valign='top'> 
				 	<img src='https://ci6.googleusercontent.com/proxy/Kqk_m_z9N-awTI-YYNBkynZxsDUaLUm7fDOTl1tIrXUTL26CWioJ3zIOrDM2UcQ8Oytloc6VuyvxhSLoc-QMZAg8mRPSk35YBQ=s0-d-e1-ft#https://secure.ccavenue.com/images/blank_spacer.gif' width='20' height='1' class='CToWUd'> 
				 </td>
				 <td width='244' align='right' valign='top'> 
				 	<table width='244' border='0' cellspacing='0' cellpadding='10'> <tbody> <tr>
				  <td align='left' valign='top' class='m_2109585722555529806innerborder m_2109585722555529806tableinner'> <table width='244' border='0' cellspacing='0' cellpadding='0'> <tbody> 
				  <tr>
				  <td width='51%' height='19' align='right' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'>Contribution made:&nbsp;
				  </td>
				 	<td width='16%' height='19' align='center' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'>INR
				   </td>
				 <td width='33%' height='19' align='right' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#373737'><?php echo $invoiceDetails[0]->amount ?> 
				</td>
				</tr>
				 	<tr>
				 	 <td colspan='3' class='m_2109585722555529806divider'> 
				 	 	<img src='https://ci6.googleusercontent.com/proxy/Kqk_m_z9N-awTI-YYNBkynZxsDUaLUm7fDOTl1tIrXUTL26CWioJ3zIOrDM2UcQ8Oytloc6VuyvxhSLoc-QMZAg8mRPSk35YBQ=s0-d-e1-ft#https://secure.ccavenue.com/images/blank_spacer.gif' width='1' height='1' class='CToWUd'>
				 	 </td>
				 	</tr>
				</tbody> 
			</table> 
		</td>
			</tr>
				</tbody>
				</table> 
			</td>
			</tr>
				</tbody> 
			</table> 
			<br><br><br><br>

			<table width='100%' border='0' cellspacing='0' cellpadding='0'> 
				<tbody> 
					<tr>
				 		<td height='1' align='left' valign='top' style='background-color:#e4e6eb;padding:0px' colspan='2'>  
				 	    </td>
					<td width='74%' align='left' valign='top' style='font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#373737'><strong>Bhaktivedanta Gurukula & International School </strong><br> Bhaktivedanta Swami Marg,
Raman Reti,<br> Vrindavan - 281121, U.P.
India<br>Email: <a href='mailto:info@newbgis.org' class='m_2109585722555529806hylink2' style='font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#373737;text-decoration:underline' target='_blank'>info@newbgis.org</a> <br>Website: <a href='http://www.newbgis.org/' class='m_2109585722555529806hylink2' style='font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#373737;text-decoration:underline' target='_blank' data-saferedirecturl='https://www.google.com/url?hl=en&amp;q=http://www.ccavenue.com/&amp;source=gmail&amp;ust=1520745983794000&amp;usg=AFQjCNE8rf71lXG7alhQFCr9wUXO9ptPtA'>www.newbgis.org</a><br> Phone : +91-7088004339</td>
<td width='26%' align='right' valign='bottom'><img src='https://ci6.googleusercontent.com/proxy/yYoAcFnxccSJ2jUQrxQTZwRafKwXd3px5H32BjN_esypKR53uAl8ve3mGF8QcM0D0ZHtmryxX_Th8vhrAXoUSCD63Wk4ArYhdNslIaQ_8Cd6huem3Ip3YRDQwDT6h8j2rwIjwQFtmQ=s0-d-e1-ft#https://dashboard.ccavenue.com/ImgStore/Images/50225_GtwSetlogo_1516705188477.png' width='109' height='85px' border='0' class='CToWUd'> </td>
</tr>
</tbody> </table> </td>
</tr>
</tbody> </table> </td>
</tr>
</tbody></table>


<table width="18%" style="font-weight: 900; font-size: 18px">
	<tr>
		<td> <a href="<?=base_url()?>dashboard"> << Back </a> </td>

    <td> <a onclick="window.print();" href="#"> Print >> </a></td>
	</tr>
</table>





								 
 
 

							 
								
							</div> 
						</div>   
					</div> 
				</div> 
			</div> 
		</div>
	</div>

