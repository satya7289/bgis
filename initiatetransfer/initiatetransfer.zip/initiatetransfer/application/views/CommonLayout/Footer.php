		    <!-- JS FILES // These should be loaded in every page -->

			<script type="text/javascript" src="<?= base_url()?>assets/js/bootstrap.min.js"></script>

			<script type="text/javascript" src="<?= base_url()?>assets/js/kl-plugins.js"></script> 


			<!-- Custom Kallyas JS codes -->

			<script type="text/javascript" src="<?= base_url()?>assets/js/kl-scripts.js"></script> 

			<!-- Demo panel -->

			<script type="text/javascript" src="<?= base_url()?>assets/js/dp.js"></script>


 

	<body> 

</html>